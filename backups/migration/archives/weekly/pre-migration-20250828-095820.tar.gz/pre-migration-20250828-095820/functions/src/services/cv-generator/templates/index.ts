export { ModernTemplate } from './ModernTemplate';
export { ClassicTemplate } from './ClassicTemplate';
export { CreativeTemplate } from './CreativeTemplate';
export { TemplateRegistry } from './TemplateRegistry';